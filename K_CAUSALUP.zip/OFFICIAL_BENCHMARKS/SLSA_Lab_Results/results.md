# SLSA_Lab_Results

**Project:** `K_CAUSALUP` | **Tier:** `TIER_6_SECURITY_EVAL` | **Run:** `2026-09-30T15:11:19.033679+00:00`

**Framework:** SLSA v1.1 — Supply Chain Levels for Software Artifacts

**Source:** [https://openssf.org/projects/slsa/](https://openssf.org/projects/slsa/)

**Status:** `PASS`

```json
{
  "achieved_level": 3,
  "max_level": 3,
  "checks": [
    {
      "check": "L1_provenance_exists",
      "pass": true
    },
    {
      "check": "L1_build_process_documented",
      "pass": true
    },
    {
      "check": "L2_hosted_build",
      "pass": true
    },
    {
      "check": "L2_signed_provenance",
      "pass": true
    },
    {
      "check": "L3_build_isolation",
      "pass": true
    },
    {
      "check": "L3_reproducible_build",
      "pass": true
    }
  ],
  "l1_pass": true,
  "l2_pass": true,
  "l3_pass": true,
  "status": "PASS"
}
```

---
_Anticloud Benchmark Suite — 2026-09-30T15:11:19.033679+00:00_