# SBOM_Lab_Results

**Project:** `K_CAUSALUP` | **Tier:** `TIER_6_SECURITY_EVAL` | **Run:** `2026-09-30T15:11:19.033679+00:00`

**Framework:** SBOM — NTIA Minimum Elements + CycloneDX/SPDX proxy

**Source:** [https://ntia.gov/sites/default/files/publications/sbom_minimum_elements_report_0.pdf](https://ntia.gov/sites/default/files/publications/sbom_minimum_elements_report_0.pdf)

**Status:** `PARTIAL`

```json
{
  "indicators": [
    {
      "field": "requirements_txt",
      "present": false
    },
    {
      "field": "pyproject_toml",
      "present": true
    },
    {
      "field": "setup_py",
      "present": false
    },
    {
      "field": "package_json",
      "present": false
    },
    {
      "field": "cargo_toml",
      "present": false
    },
    {
      "field": "go_mod",
      "present": false
    },
    {
      "field": "licence_file",
      "present": true
    },
    {
      "field": "authors_documented",
      "present": true
    },
    {
      "field": "version_pinned",
      "present": true
    }
  ],
  "present": 4,
  "total": 9,
  "completeness_pct": 44,
  "status": "PARTIAL"
}
```

---
_Anticloud Benchmark Suite — 2026-09-30T15:11:19.033679+00:00_