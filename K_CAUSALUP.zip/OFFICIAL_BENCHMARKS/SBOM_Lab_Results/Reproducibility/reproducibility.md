# Reproducibility Record: SBOM_Lab_Results

**Project:** `K_CAUSALUP`  
**Benchmark:** `SBOM_Lab_Results`  
**Run:** `2026-09-30T15:11:19.033679+00:00`  
**Based on:** [HELM reproducibility principles](https://github.com/stanford-crfm/helm)

## Environment

| Field | Value |
| ----- | ----- |
| Platform | `win32` |
| Python | `3.12.10` |
| OS | `nt` |

## Inputs

| Field | Value |
| ----- | ----- |
| Slug | `py-why/dowhy` |
| Commit | `cc23521127ba` |
| Tracked files | `528` |
| Source lines | `53037` |
| Licence | `MIT` |
| Inputs SHA256 | `108fbf2c7f2d3442...` |

## Outputs

| Field | Value |
| ----- | ----- |
| Results file | `TIER_6_SECURITY_EVAL\K_CAUSALUP\OFFICIAL_BENCHMARKS\SBOM_Lab_Results\results.json` |
| Results SHA256 | `ce76e888feb2eda4...` |

## Reproduction Steps

- 1. Clone Anticloud at commit HEAD
- 2. Ensure E:\fenta\Downloads\The Anticloud is present
- 3. Run: python run_benchmarks_comprehensive.py
- 4. Run: python write_benchmark_subfolders.py
- 5. Run: python write_ledgers_repro_extra_benchmarks.py
- 6. Verify results_sha256 matches sha256(OFFICIAL_BENCHMARKS/SBOM_Lab_Results/results.json)

## Notes

TRL/OSINT/OWASP/SOC2/ISO27001/MITRE/NIST use static code analysis. HF uses live CPU inference.

---
_Anticloud Reproducibility Standard v1 — 2026-09-30T15:11:19.033679+00:00_