# Enterprise License and Pricing — K_CAUSALUP

**Project:** `K_CAUSALUP`
**Tier:** TIER_6_SECURITY_EVAL
**Domain:** security evaluation, red-team, MITRE ATT&CK, OSINT, threat detection
**Maintainer:** Anticloud FZ LLE · 0-1.gg · lois@0-1.gg · Dubai, UAE
**Model:** Anticloud PAX L5 Narrow L2 General 27B
**AIOSS Chain:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
**Date:** October 2026

---

## Licensing Overview

`K_CAUSALUP` is released under a dual license:

1. **Apache 2.0** — For open-source use, research, education, and non-commercial deployment
2. **Anticommons Enterprise License 1.0** — For commercial, government, and regulated-sector deployment

## Anticommons Enterprise License 1.0

The Anticommons Enterprise License is a commercial license designed for organizations that require:
- Production deployment in regulated environments (HIPAA, FedRAMP, GDPR, PCI-DSS, EU AI Act)
- SLA guarantees and dedicated support
- Whitelabelling and OEM redistribution rights
- Compliance documentation and audit support
- Access to the full Anticloud corpus and fine-tuning services

## Pricing Tiers

| Tier | Org Size | Annual Price | Included |
|---|---|---|---|
| **Startup** | <50 employees | **$18,000/yr** | 1 deployment node, AIOSS chain, basic compliance reports |
| **SME** | 50–500 employees | **$75,000/yr** | 3 deployment nodes, full compliance suite, quarterly audit package |
| **Enterprise** | 500–5,000 employees | **$350,000/yr** | Unlimited nodes, custom fine-tuning, dedicated support |
| **Large Enterprise** | 5,000–50,000 employees | **$1,200,000/yr** | Multi-region, FedRAMP support, SLA 99.9%, red team access |
| **Strategic / Government** | 50,000+ / national | **$5,000,000/yr** | Full sovereign deployment, air-gap cert, regulatory co-filing |

## Academic and Research License

Non-commercial academic research use of `K_CAUSALUP` is permitted under Apache 2.0 at no cost, with attribution to Anticloud FZ LLE and ORCID 0009-0009-2233-6107.

## Non-Dilutive Investment

Anticloud FZ LLE is available for non-dilutive investment partnerships. Current raise scenarios:
- $1M angel / design partner round
- $80M / 10% equity for full GTM activation

**Enquiries:** lois@0-1.gg · 0-1.gg · 0-1.gg
