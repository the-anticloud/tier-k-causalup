# Upstream Provenance

**Project:** `K_CAUSALUP`  
**Tier:** TIER_6_SECURITY_EVAL  
**Identity:** Upstream `py-why/dowhy` @ `cc23521127ba` (MIT)

## Recorded identity

| Fact | Value |
| --- | --- |
| Upstream | `py-why/dowhy` |
| Commit | `cc23521127ba21ade40514539ae7b91db27ca54a` |
| Upstream licence | MIT |
| Licence class | permissive |
| Clone size | 25.62 MB |
| Ledger | 0 blocks, chain verified |
| Current TRL | NOT YET MEASURED |
| Post-optimisation TRL | NOT YET MEASURED |
| II budget cap | 1500.0 IIU |
| Verified upstream edits | 1 |

## Obligation

`K_CAUSALUP` is vendored under MIT (permissive). Any Anticloud edit to
the vendored tree is a derivative work and is tracked in
`anticloud-edits.json`; the notice of changes is at the project `NOTICE.md`.
Where the licence class is `unknown`, no edit may be applied until the
licence is identified, because the absence of a licence is not a grant.
