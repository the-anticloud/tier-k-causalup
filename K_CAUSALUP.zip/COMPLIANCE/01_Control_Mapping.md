# control to evidence, with unmapped controls listed

**Project:** `K_CAUSALUP`  
**Tier:** TIER_6_SECURITY_EVAL  
**Identity:** Upstream `py-why/dowhy` @ `cc23521127ba` (MIT)

## Purpose

Control mapping, evidence, and honest gaps.

## This project

| Fact | Value |
| --- | --- |
| Upstream | `py-why/dowhy` |
| Commit | `cc23521127ba21ade40514539ae7b91db27ca54a` |
| Upstream licence | MIT |
| Licence class | permissive |
| Clone size | 25.62 MB |
| Ledger | 0 blocks, chain verified |
| Current TRL | NOT YET MEASURED |
| Post-optimisation TRL | NOT YET MEASURED |
| II budget cap | 1500.0 IIU |
| Verified upstream edits | 1 |

## Known gaps

Everything above is read from an artifact. Where this document says
`NOT YET MEASURED`, the value has not been measured for `K_CAUSALUP` as of
generation. Filling those in requires a run or a decision, not editing.
